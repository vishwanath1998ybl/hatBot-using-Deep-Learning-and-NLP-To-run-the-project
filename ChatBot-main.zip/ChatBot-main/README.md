# ChatBot
ChatBot using Deep Learning and NLP


# To run the project Execute chatbot.py file and then launch the browser and start the server 127.0.0.0:5500/

